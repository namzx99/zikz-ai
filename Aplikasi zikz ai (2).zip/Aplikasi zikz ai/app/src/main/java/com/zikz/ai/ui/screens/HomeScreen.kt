package com.zikz.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.zikz.ai.ui.components.GlassCard
import com.zikz.ai.ui.navigation.Screen
import com.zikz.ai.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    val categories = listOf(
        AIFeature("AI Chat", Icons.Default.Chat, Screen.Chat.route, listOf(AuroraPurple, AuroraViolet)),
        AIFeature("AI Image", Icons.Default.Image, Screen.Image.route, listOf(AuroraBlue, AuroraCyan)),
        AIFeature("AI Code", Icons.Default.Code, Screen.Code.route, listOf(AuroraCyan, AuroraBlue)),
        AIFeature("AI Writer", Icons.Default.Edit, Screen.Writer.route, listOf(AuroraPink, AuroraPurple)),
        AIFeature("AI PDF", Icons.Default.PictureAsPdf, Screen.PDF.route, listOf(AccentOrange, AccentRed)),
        AIFeature("AI Translate", Icons.Default.Translate, Screen.Translate.route, listOf(AccentGreen, AuroraCyan)),
        AIFeature("AI Study", Icons.Default.School, Screen.Study.route, listOf(AuroraViolet, AuroraPink)),
        AIFeature("AI Video", Icons.Default.VideoLibrary, Screen.Video.route, listOf(AuroraPurple, AuroraBlue))
    )
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Welcome Back",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "What would you like to create today?",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Profile.route) }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Profile")
                    }
                    IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BackgroundDark
                )
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = "AI Features",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
            }
            
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(600.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(categories) { feature ->
                        AIFeatureCard(feature) {
                            navController.navigate(feature.route)
                        }
                    }
                }
            }
            
            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Premium Features",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Unlock unlimited AI power",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondaryDark
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Premium",
                            tint = AccentYellow,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }
    }
}

data class AIFeature(
    val name: String,
    val icon: ImageVector,
    val route: String,
    val gradientColors: List<Color>
)

@Composable
fun AIFeatureCard(feature: AIFeature, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(20.dp))
            .background(
                brush = Brush.verticalGradient(feature.gradientColors)
            )
            .clickable(onClick = onClick)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = feature.icon,
                contentDescription = feature.name,
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = feature.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
    }
}
