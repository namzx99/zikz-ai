package com.zikz.ai.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = AuroraPurple,
    onPrimary = TextPrimaryDark,
    primaryContainer = SurfaceVariantDark,
    onPrimaryContainer = TextSecondaryDark,
    
    secondary = AuroraBlue,
    onSecondary = TextPrimaryDark,
    secondaryContainer = SurfaceContainerDark,
    onSecondaryContainer = TextSecondaryDark,
    
    tertiary = AuroraCyan,
    onTertiary = TextPrimaryDark,
    tertiaryContainer = SurfaceVariantDark,
    onTertiaryContainer = TextSecondaryDark,
    
    background = BackgroundDark,
    onBackground = TextPrimaryDark,
    
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    
    error = AccentRed,
    onError = TextPrimaryDark,
    errorContainer = SurfaceVariantDark,
    onErrorContainer = AccentRed,
    
    outline = TextTertiaryDark,
    outlineVariant = SurfaceVariantDark,
    
    scrim = BackgroundDark,
    
    inverseSurface = SurfaceLight,
    inverseOnSurface = TextPrimaryLight,
    inversePrimary = AuroraPurple,
    
    surfaceTint = AuroraPurple,
)

private val LightColorScheme = lightColorScheme(
    primary = AuroraPurple,
    onPrimary = TextPrimaryLight,
    primaryContainer = SurfaceVariantLight,
    onPrimaryContainer = TextSecondaryLight,
    
    secondary = AuroraBlue,
    onSecondary = TextPrimaryLight,
    secondaryContainer = SurfaceContainerLight,
    onSecondaryContainer = TextSecondaryLight,
    
    tertiary = AuroraCyan,
    onTertiary = TextPrimaryLight,
    tertiaryContainer = SurfaceVariantLight,
    onTertiaryContainer = TextSecondaryLight,
    
    background = BackgroundLight,
    onBackground = TextPrimaryLight,
    
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextSecondaryLight,
    
    error = AccentRed,
    onError = TextPrimaryLight,
    errorContainer = SurfaceVariantLight,
    onErrorContainer = AccentRed,
    
    outline = TextTertiaryLight,
    outlineVariant = SurfaceVariantLight,
    
    scrim = BackgroundLight,
    
    inverseSurface = SurfaceDark,
    inverseOnSurface = TextPrimaryDark,
    inversePrimary = AuroraPurple,
    
    surfaceTint = AuroraPurple,
)

@Composable
fun ZikzAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
