package com.zikz.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zikz.ai.ui.theme.*

@Composable
fun ZikzButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    icon: @Composable (() -> Unit)? = null,
    variant: ButtonVariant = ButtonVariant.Primary
) {
    val interactionSource = remember { MutableInteractionSource() }
    
    val gradientColors = when (variant) {
        ButtonVariant.Primary -> listOf(AuroraPurple, AuroraBlue)
        ButtonVariant.Secondary -> listOf(AuroraBlue, AuroraCyan)
        ButtonVariant.Success -> listOf(AccentGreen, AccentGreen)
        ButtonVariant.Danger -> listOf(AccentRed, AccentRed)
        ButtonVariant.Outline -> listOf(Color.Transparent, Color.Transparent)
    }
    
    Box(
        modifier = modifier
            .shadow(
                elevation = if (variant == ButtonVariant.Outline) 0.dp else 8.dp,
                shape = RoundedCornerShape(16.dp),
                spotColor = gradientColors[0].copy(alpha = 0.3f)
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (variant == ButtonVariant.Outline) {
                    Color.Transparent
                } else {
                    Brush.horizontalGradient(gradientColors)
                }
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled && !isLoading,
                onClick = onClick
            )
            .padding(horizontal = 24.dp, vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = Color.White,
                strokeWidth = 2.dp
            )
        } else {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                icon?.invoke()
                if (icon != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = if (variant == ButtonVariant.Outline) MaterialTheme.colorScheme.primary else Color.White
                )
            }
        }
    }
}

enum class ButtonVariant {
    Primary,
    Secondary,
    Success,
    Danger,
    Outline
}
