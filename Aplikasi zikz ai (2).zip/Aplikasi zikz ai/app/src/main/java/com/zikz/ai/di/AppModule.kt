package com.zikz.ai.di

import android.content.Context
import androidx.room.Room
import com.zikz.ai.data.database.ZikzDatabase
import com.zikz.ai.data.repository.ChatRepository
import com.zikz.ai.data.repository.UserRepository
import com.zikz.ai.data.preferences.PreferencesManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Provides
    @Singleton
    fun provideZikzDatabase(@ApplicationContext context: Context): ZikzDatabase {
        return Room.databaseBuilder(
            context,
            ZikzDatabase::class.java,
            "zikz_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }
    
    @Provides
    @Singleton
    fun provideUserDao(database: ZikzDatabase) = database.userDao()
    
    @Provides
    @Singleton
    fun provideChatMessageDao(database: ZikzDatabase) = database.chatMessageDao()
    
    @Provides
    @Singleton
    fun providePreferencesManager(@ApplicationContext context: Context): PreferencesManager {
        return PreferencesManager(context)
    }
    
    @Provides
    @Singleton
    fun provideUserRepository(database: ZikzDatabase): UserRepository {
        return UserRepository(database.userDao())
    }
    
    @Provides
    @Singleton
    fun provideChatRepository(database: ZikzDatabase): ChatRepository {
        return ChatRepository(database.chatMessageDao())
    }
}
