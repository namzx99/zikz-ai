package com.zikz.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zikz.ai.data.models.ChatMessage
import com.zikz.ai.data.repository.ChatRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository
) : ViewModel() {
    
    private val _currentConversationId = MutableStateFlow(UUID.randomUUID().toString())
    val currentConversationId: StateFlow<String> = _currentConversationId.asStateFlow()
    
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    init {
        loadMessages()
    }
    
    private fun loadMessages() {
        viewModelScope.launch {
            chatRepository.getMessagesByConversation(currentConversationId.value)
                .collect { messageList ->
                    _messages.value = messageList
                }
        }
    }
    
    fun sendMessage(content: String, imageUrl: String? = null) {
        viewModelScope.launch {
            val userMessage = ChatMessage(
                conversationId = currentConversationId.value,
                content = content,
                isFromUser = true,
                imageUrl = imageUrl
            )
            chatRepository.insertMessage(userMessage)
            
            // Simulate AI response
            _isLoading.value = true
            kotlinx.coroutines.delay(1000)
            
            val aiResponse = ChatMessage(
                conversationId = currentConversationId.value,
                content = "This is a simulated AI response to: $content\n\nZikz AI is ready to help you!",
                isFromUser = false
            )
            chatRepository.insertMessage(aiResponse)
            _isLoading.value = false
        }
    }
    
    fun toggleBookmark(messageId: String) {
        viewModelScope.launch {
            val message = _messages.value.find { it.id == messageId }
            message?.let {
                val updated = it.copy(isBookmarked = !it.isBookmarked)
                chatRepository.updateMessage(updated)
            }
        }
    }
    
    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            val message = _messages.value.find { it.id == messageId }
            message?.let {
                chatRepository.deleteMessage(it)
            }
        }
    }
    
    fun clearConversation() {
        viewModelScope.launch {
            chatRepository.deleteConversationMessages(currentConversationId.value)
            _currentConversationId.value = UUID.randomUUID().toString()
            loadMessages()
        }
    }
}
