package com.zikz.ai.data.repository

import com.zikz.ai.data.database.UserDao
import com.zikz.ai.data.models.User
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class UserRepository @Inject constructor(
    private val userDao: UserDao
) {
    
    fun getUserById(uid: String): Flow<User?> {
        return userDao.getUserByIdFlow(uid)
    }
    
    suspend fun insertUser(user: User) {
        userDao.insertUser(user)
    }
    
    suspend fun updateUser(user: User) {
        userDao.updateUser(user)
    }
    
    suspend fun deleteUser(user: User) {
        userDao.deleteUser(user)
    }
    
    suspend fun deleteAllUsers() {
        userDao.deleteAllUsers()
    }
}
