package com.zikz.ai.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.zikz.ai.data.models.ChatMessage
import com.zikz.ai.data.models.User

@Database(
    entities = [
        User::class,
        ChatMessage::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ZikzDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun chatMessageDao(): ChatMessageDao
}
