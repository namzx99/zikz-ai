package com.zikz.ai.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object Chat : Screen("chat")
    object Image : Screen("image")
    object Video : Screen("video")
    object Code : Screen("code")
    object PDF : Screen("pdf")
    object Translate : Screen("translate")
    object Study : Screen("study")
    object Writer : Screen("writer")
    object History : Screen("history")
    object Bookmarks : Screen("bookmarks")
    object Settings : Screen("settings")
    object Profile : Screen("profile")
}
