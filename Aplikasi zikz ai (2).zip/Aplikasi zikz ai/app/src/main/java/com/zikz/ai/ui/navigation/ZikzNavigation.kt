package com.zikz.ai.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.zikz.ai.ui.screens.*
import com.zikz.ai.ui.viewmodel.AuthViewModel

@Composable
fun ZikzNavigation() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = hiltViewModel()
    val isLoggedIn by authViewModel.isLoggedIn.collectAsState()
    
    val startDestination = if (isLoggedIn) Screen.Home.route else Screen.Splash.route
    
    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            slideInHorizontally(
                initialOffsetX = { 1000 },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        exitTransition = {
            slideOutHorizontally(
                targetOffsetX = { -1000 },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        },
        popEnterTransition = {
            slideInHorizontally(
                initialOffsetX = { -1000 },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            slideOutHorizontally(
                targetOffsetX = { 1000 },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        }
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(navController)
        }
        
        composable(Screen.Login.route) {
            LoginScreen(navController)
        }
        
        composable(Screen.Register.route) {
            RegisterScreen(navController)
        }
        
        composable(Screen.Home.route) {
            HomeScreen(navController)
        }
        
        composable(Screen.Chat.route) {
            ChatScreen(navController)
        }
        
        composable(Screen.Image.route) {
            ImageGeneratorScreen(navController)
        }
        
        composable(Screen.Video.route) {
            VideoGeneratorScreen(navController)
        }
        
        composable(Screen.Code.route) {
            CodeGeneratorScreen(navController)
        }
        
        composable(Screen.PDF.route) {
            PDFScreen(navController)
        }
        
        composable(Screen.Translate.route) {
            TranslateScreen(navController)
        }
        
        composable(Screen.Study.route) {
            StudyScreen(navController)
        }
        
        composable(Screen.Writer.route) {
            WriterScreen(navController)
        }
        
        composable(Screen.History.route) {
            HistoryScreen(navController)
        }
        
        composable(Screen.Bookmarks.route) {
            BookmarksScreen(navController)
        }
        
        composable(Screen.Settings.route) {
            SettingsScreen(navController)
        }
        
        composable(Screen.Profile.route) {
            ProfileScreen(navController)
        }
    }
}
