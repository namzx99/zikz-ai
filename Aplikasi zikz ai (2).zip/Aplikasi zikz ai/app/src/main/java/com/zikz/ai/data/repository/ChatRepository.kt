package com.zikz.ai.data.repository

import com.zikz.ai.data.database.ChatMessageDao
import com.zikz.ai.data.models.ChatMessage
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ChatRepository @Inject constructor(
    private val chatMessageDao: ChatMessageDao
) {
    
    fun getMessagesByConversation(conversationId: String): Flow<List<ChatMessage>> {
        return chatMessageDao.getMessagesByConversation(conversationId)
    }
    
    fun getBookmarkedMessages(): Flow<List<ChatMessage>> {
        return chatMessageDao.getBookmarkedMessages()
    }
    
    fun getPinnedMessages(): Flow<List<ChatMessage>> {
        return chatMessageDao.getPinnedMessages()
    }
    
    fun getRecentMessages(limit: Int = 50): Flow<List<ChatMessage>> {
        return chatMessageDao.getRecentMessages(limit)
    }
    
    suspend fun insertMessage(message: ChatMessage) {
        chatMessageDao.insertMessage(message)
    }
    
    suspend fun insertMessages(messages: List<ChatMessage>) {
        chatMessageDao.insertMessages(messages)
    }
    
    suspend fun updateMessage(message: ChatMessage) {
        chatMessageDao.updateMessage(message)
    }
    
    suspend fun deleteMessage(message: ChatMessage) {
        chatMessageDao.deleteMessage(message)
    }
    
    suspend fun deleteConversationMessages(conversationId: String) {
        chatMessageDao.deleteConversationMessages(conversationId)
    }
    
    suspend fun deleteAllMessages() {
        chatMessageDao.deleteAllMessages()
    }
    
    suspend fun getMessageCount(conversationId: String): Int {
        return chatMessageDao.getMessageCount(conversationId)
    }
}
