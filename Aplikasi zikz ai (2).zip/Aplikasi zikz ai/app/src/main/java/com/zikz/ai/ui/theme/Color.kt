package com.zikz.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Aurora Gradient
val AuroraPurple = Color(0xFF8B5CF6)
val AuroraBlue = Color(0xFF3B82F6)
val AuroraCyan = Color(0xFF06B6D4)
val AuroraPink = Color(0xFFEC4899)
val AuroraViolet = Color(0xFF7C3AED)

// Background Colors - Dark Theme
val BackgroundDark = Color(0xFF0A0A0F)
val SurfaceDark = Color(0xFF121218)
val SurfaceVariantDark = Color(0xFF1A1A24)
val SurfaceContainerDark = Color(0xFF1F1F2E)

// Background Colors - Light Theme
val BackgroundLight = Color(0xFFFAFAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF5F5F7)
val SurfaceContainerLight = Color(0xFFE5E5EA)

// Text Colors
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFB4B4C8)
val TextTertiaryDark = Color(0xFF6B6B7F)

val TextPrimaryLight = Color(0xFF000000)
val TextSecondaryLight = Color(0xFF3C3C43)
val TextTertiaryLight = Color(0xFF8E8E93)

// Accent Colors
val AccentGreen = Color(0xFF10B981)
val AccentRed = Color(0xFFEF4444)
val AccentYellow = Color(0xFFF59E0B)
val AccentOrange = Color(0xFFF97316)

// Glassmorphism
val GlassWhite = Color(0x1AFFFFFF)
val GlassBlack = Color(0x1A000000)
val GlassBorder = Color(0x33FFFFFF)

// Glow Colors
val GlowPurple = Color(0x408B5CF6)
val GlowBlue = Color(0x403B82F6)
val GlowPink = Color(0x40EC4899)
val GlowCyan = Color(0x4006B6D4)

// Card Colors
val CardDark = Color(0xFF1A1A24)
val CardLight = Color(0xFFFFFFFF)

// Gradient Colors
val GradientStart = Color(0xFF8B5CF6)
val GradientMiddle = Color(0xFF3B82F6)
val GradientEnd = Color(0xFF06B6D4)

// Chat Colors
val UserMessageBg = Color(0xFF7C3AED)
val AIMessageBg = Color(0xFF1F1F2E)
val CodeBlockBg = Color(0xFF1E1E2E)

// Status Colors
val StatusOnline = Color(0xFF10B981)
val StatusOffline = Color(0xFF6B7280)
val StatusBusy = Color(0xFFEF4444)

// Shimmer Colors
val ShimmerBase = Color(0xFF2A2A3A)
val ShimmerHighlight = Color(0xFF3A3A4A)
