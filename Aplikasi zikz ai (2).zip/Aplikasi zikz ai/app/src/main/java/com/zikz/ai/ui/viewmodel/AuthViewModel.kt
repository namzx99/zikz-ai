package com.zikz.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zikz.ai.data.preferences.PreferencesManager
import com.zikz.ai.data.repository.UserRepository
import com.zikz.ai.data.models.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val preferencesManager: PreferencesManager,
    private val userRepository: UserRepository
) : ViewModel() {
    
    val isLoggedIn = preferencesManager.isLoggedIn.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        false
    )
    
    val userId = preferencesManager.userId.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ""
    )
    
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()
    
    init {
        viewModelScope.launch {
            userId.collect { uid ->
                if (uid.isNotEmpty()) {
                    userRepository.getUserById(uid).collect { user ->
                        _currentUser.value = user
                    }
                }
            }
        }
    }
    
    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                // TODO: Implement Firebase authentication
                // For now, simulate successful login
                val user = User(
                    uid = "demo_user",
                    email = email,
                    displayName = "Demo User",
                    photoUrl = "",
                    isPremium = false
                )
                userRepository.insertUser(user)
                preferencesManager.setUserId(user.uid)
                preferencesManager.setLoggedIn(true)
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun register(email: String, password: String, displayName: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                // TODO: Implement Firebase authentication
                val user = User(
                    uid = "demo_user",
                    email = email,
                    displayName = displayName,
                    photoUrl = "",
                    isPremium = false
                )
                userRepository.insertUser(user)
                preferencesManager.setUserId(user.uid)
                preferencesManager.setLoggedIn(true)
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun logout() {
        viewModelScope.launch {
            preferencesManager.setLoggedIn(false)
            preferencesManager.setUserId("")
            userRepository.deleteAllUsers()
            _currentUser.value = null
        }
    }
    
    fun resetAuthState() {
        _authState.value = AuthState.Idle
    }
}

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    object Success : AuthState()
    data class Error(val message: String) : AuthState()
}
