package com.zikz.ai.data.models

import androidx.compose.ui.graphics.vector.ImageVector

data class AICategory(
    val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val route: String,
    val gradientColors: List<Long> = listOf(),
    val isPremium: Boolean = false
)

data class PromptTemplate(
    val id: String,
    val title: String,
    val description: String,
    val prompt: String,
    val category: String,
    val isFavorite: Boolean = false,
    val usageCount: Int = 0
)

data class GeneratedImage(
    val id: String,
    val prompt: String,
    val imageUrl: String,
    val timestamp: Long = System.currentTimeMillis(),
    val width: Int = 512,
    val height: Int = 512,
    val style: String = "default"
)

data class GeneratedCode(
    val id: String,
    val language: String,
    val code: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class PDFDocument(
    val id: String,
    val fileName: String,
    val filePath: String,
    val pageCount: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val summary: String = ""
)

data class Translation(
    val id: String,
    val sourceText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class StudyMaterial(
    val id: String,
    val title: String,
    val content: String,
    val type: String, // flashcard, quiz, summary
    val subject: String,
    val timestamp: Long = System.currentTimeMillis()
)
