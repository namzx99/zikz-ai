package com.zikz.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.zikz.ai.ui.components.*
import com.zikz.ai.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CodeGeneratorScreen(navController: NavController) {
    var prompt by remember { mutableStateOf("") }
    var selectedLanguage by remember { mutableStateOf("Kotlin") }
    var generatedCode by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    
    val languages = listOf("Kotlin", "Java", "Python", "JavaScript", "TypeScript", "C++", "Swift", "Go")
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "AI Code Generator",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BackgroundDark
                )
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GlassCard {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "What do you want to build?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                    
                    ZikzTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        placeholder = "Create a function to...",
                        maxLines = 3,
                        singleLine = false
                    )
                    
                    Text(
                        text = "Select Language",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondaryDark
                    )
                    
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        languages.forEach { language ->
                            FilterChip(
                                selected = selectedLanguage == language,
                                onClick = { selectedLanguage = language },
                                label = { Text(language) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AuroraPurple,
                                    selectedLabelColor = androidx.compose.ui.graphics.Color.White
                                )
                            )
                        }
                    }
                    
                    ZikzButton(
                        text = "Generate Code",
                        onClick = {
                            isGenerating = true
                            generatedCode = "// Generated $selectedLanguage code\n" +
                                    "fun example() {\n" +
                                    "    println(\"Hello from Zikz AI!\")\n" +
                                    "}\n\n" +
                                    "// This is a demo code generation"
                            isGenerating = false
                        },
                        isLoading = isGenerating,
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = "Generate",
                                tint = androidx.compose.ui.graphics.Color.White
                            )
                        }
                    )
                }
            }
            
            if (generatedCode.isNotEmpty()) {
                GlassCard {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Generated Code",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            IconButton(onClick = { /* Copy code */ }) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = AuroraPurple
                                )
                            }
                        }
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CodeBlockBg)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = generatedCode,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = TextPrimaryDark
                            )
                        }
                    }
                }
            }
        }
    }
}
