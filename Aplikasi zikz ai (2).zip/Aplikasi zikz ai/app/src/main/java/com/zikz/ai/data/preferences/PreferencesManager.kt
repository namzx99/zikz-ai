package com.zikz.ai.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "zikz_preferences")

class PreferencesManager(private val context: Context) {
    
    private val dataStore = context.dataStore
    
    companion object {
        private val IS_DARK_THEME = booleanPreferencesKey("is_dark_theme")
        private val LANGUAGE = stringPreferencesKey("language")
        private val IS_FIRST_LAUNCH = booleanPreferencesKey("is_first_launch")
        private val USER_ID = stringPreferencesKey("user_id")
        private val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        private val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        private val NOTIFICATION_ENABLED = booleanPreferencesKey("notification_enabled")
        private val API_KEY = stringPreferencesKey("api_key")
        private val FONT_SIZE = floatPreferencesKey("font_size")
    }
    
    val isDarkTheme: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[IS_DARK_THEME] ?: true
    }
    
    val language: Flow<String> = dataStore.data.map { preferences ->
        preferences[LANGUAGE] ?: "en"
    }
    
    val isFirstLaunch: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[IS_FIRST_LAUNCH] ?: true
    }
    
    val isLoggedIn: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[IS_LOGGED_IN] ?: false
    }
    
    val userId: Flow<String> = dataStore.data.map { preferences ->
        preferences[USER_ID] ?: ""
    }
    
    val biometricEnabled: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[BIOMETRIC_ENABLED] ?: false
    }
    
    val notificationEnabled: Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[NOTIFICATION_ENABLED] ?: true
    }
    
    val apiKey: Flow<String> = dataStore.data.map { preferences ->
        preferences[API_KEY] ?: ""
    }
    
    val fontSize: Flow<Float> = dataStore.data.map { preferences ->
        preferences[FONT_SIZE] ?: 1.0f
    }
    
    suspend fun setDarkTheme(isDark: Boolean) {
        dataStore.edit { preferences ->
            preferences[IS_DARK_THEME] = isDark
        }
    }
    
    suspend fun setLanguage(lang: String) {
        dataStore.edit { preferences ->
            preferences[LANGUAGE] = lang
        }
    }
    
    suspend fun setFirstLaunch(isFirst: Boolean) {
        dataStore.edit { preferences ->
            preferences[IS_FIRST_LAUNCH] = isFirst
        }
    }
    
    suspend fun setLoggedIn(isLogged: Boolean) {
        dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = isLogged
        }
    }
    
    suspend fun setUserId(uid: String) {
        dataStore.edit { preferences ->
            preferences[USER_ID] = uid
        }
    }
    
    suspend fun setBiometricEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[BIOMETRIC_ENABLED] = enabled
        }
    }
    
    suspend fun setNotificationEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[NOTIFICATION_ENABLED] = enabled
        }
    }
    
    suspend fun setApiKey(key: String) {
        dataStore.edit { preferences ->
            preferences[API_KEY] = key
        }
    }
    
    suspend fun setFontSize(size: Float) {
        dataStore.edit { preferences ->
            preferences[FONT_SIZE] = size
        }
    }
    
    suspend fun clearAll() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
