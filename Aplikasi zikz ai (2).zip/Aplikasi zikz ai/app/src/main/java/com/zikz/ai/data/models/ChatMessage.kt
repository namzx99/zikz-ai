package com.zikz.ai.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val conversationId: String = "",
    val content: String = "",
    val isFromUser: Boolean = true,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUrl: String? = null,
    val isBookmarked: Boolean = false,
    val isPinned: Boolean = false,
    val metadata: String? = null
)

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val lastMessage: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val isArchived: Boolean = false
)
